package io.shreyash.rush.blocks;

public enum AccessType {
  READ, WRITE, READ_WRITE, INVISIBLE
}
